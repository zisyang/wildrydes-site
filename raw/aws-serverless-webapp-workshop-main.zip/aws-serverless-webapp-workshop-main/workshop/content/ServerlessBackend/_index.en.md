+++
copyright = "Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved."
spdx-license-identifier = "CC-BY-SA-4.0"
title = "Serverless Backend"
date = 2019-09-09T17:41:51+01:00
weight = 30
chapter = true
pre = "<b>3. </b>"
+++
