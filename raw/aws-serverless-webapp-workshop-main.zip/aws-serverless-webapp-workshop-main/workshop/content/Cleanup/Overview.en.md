+++
copyright = "Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved."
spdx-license-identifier = "CC-BY-SA-4.0"
title = "Overview"
date = 2019-09-09T17:35:12+01:00
weight = 5
+++

This page provides instructions for cleaning up the resources created during the preceding modules.
