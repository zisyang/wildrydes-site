<template>
<div class="page-unicorns">
    
    <menus class="site-header" :extraHeader="true" :title="title" :logoColor="'dark'"  />

 <div class="row column medium-10 large-8 xxlarge-6">
    <p class="content">
      Wild Rydes has a dedicated staff that recruits, trains, and tends to our herd of unicorns. We take great pride in the quality of unicorns and rydes that we provide to our customers, and our staff exercises the utmost care in vetting the unicorns that join our herd.
    </p>
    <p class="content">
      Every unicorn goes through a rigorous due diligence process where we perform background checks, flying exams, and several rounds of interviews. Unicorns accepted to Wild Rydes are then treated to the best care and maintenance possible. We provide them excellent benefits, health care, and employee perks. This is part of our company philosophy in which happy unicorns lead to happy customers.
    </p>
    <p class="content">Meet a few of the unicorns that are part of our family.</p>
  </div>

  <section class="unicorns-list">

    <div class="row">
      <div class="unicorn jimmy">
        <div class="columns medium-5 large-6 xlarge-5 xlarge-offset-1">
          <img src="images/wr-unicorn-one.png" alt="Jimmy Three Legs">
        </div>

        <div class="columns medium-7 large-6 xlarge-5 xxlarge-4">
          <h2 class="title">Bucephalus</h2>
          <div class="subtitle">Golden Swiss</div>
          <p class="content">
            Bucephalus joined Wild Rydes in February 2016 and has been giving rydes almost daily. He says he most enjoys getting to know each of his ryders, which makes the job more interesting for him. In his spare time, Bucephalus enjoys watching sunsets and playing Pokemon Go.
          </p>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="unicorn henry">
        <div class="columns medium-5 medium-push-7 large-6 large-push-6 xlarge-5 xlarge-offset-1 xlarge-push-5">
          <img src="images/wr-unicorn-two.png" alt="Hot Shoe Henry">
        </div>

        <div class="columns medium-7 medium-pull-5 large-6 large-pull-6 xlarge-5 xlarge-pull-5 xxlarge-4 xxlarge-offset-1">
          <h2 class="title">Shadowfox</h2>
          <div class="subtitle">Brown Jersey</div>
          <p class="content">
            Shadowfox joined Wild Rydes after completing a distinguished career in the military, where he toured the world in many critical missions. Shadowfox enjoys impressing his ryders with magic tricks that he learned from his previous owner.
          </p>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="unicorn veronica">
        <div class="columns medium-5 large-6 xlarge-5 xlarge-offset-1">
          <img src="images/wr-unicorn-three.png" alt="Veronica">
        </div>

        <div class="columns medium-7 large-6 xlarge-5 xxlarge-4">
          <h2 class="title">Rocinante</h2>
          <div class="subtitle">Baby Flying Yellowback</div>
          <p class="content">
            Rocinante recently joined the Wild Rydes team in Madrid, Spain. She was instrumental in forming Wild Rydes’ Spanish operations after a long, distinguished acting career in windmill shadow-jousting.
          </p>
        </div>
      </div>
    </div>
  </section>
  <footers />
</div>

</template>

<script>
import footers from '@/components/footer.vue'
import menu from '@/components/menu.vue'

export default {
  name: 'unicorns',
  data(){
    return{
      title:"Unicorns Are Our Friends",
      content:"The app is what makes this service exist, but the unicorns make it move. Meet them and see who you are riding with!"
    }
  },
  components: {
    footers: footers,
    menus: menu
  },
}
</script>

