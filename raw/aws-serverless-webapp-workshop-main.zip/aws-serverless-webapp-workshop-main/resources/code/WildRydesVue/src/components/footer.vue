<template>
   <footer class="site-footer">
    <div class="row column">
      <nav class="footer-nav">
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="unicorns.html">Meet the Unicorns</a></li>
          <li><a href="investors.html">Investors & Board of Directors</a></li>
          <li><a href="faq.html">FAQ</a></li>
          <li><a href="apply.html">Apply</a></li>
        </ul>
      </nav>
    </div>
    <div class="row column">
      <div class="footer-legal">
        &copy;WildRydes Inc<br>
        All Rights Reserved
      </div>
    </div>
  </footer>
</template>